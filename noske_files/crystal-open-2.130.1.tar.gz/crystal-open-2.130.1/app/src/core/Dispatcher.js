function DispatcherClass() {
    riot.observable(this);
}

window.Dispatcher = new DispatcherClass();