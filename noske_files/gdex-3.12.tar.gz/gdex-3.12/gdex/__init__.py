from __future__ import division # we want float division!
import os
import manatee
import random
import yaml
import re
import classifiers
from sanitization import sanitize
from default import DEFAULT_CONFIG

EVAL_FAILED_SCORE = 0
GDEXATTR = 'gdex'
DEFAULT_COEF = 999
ALWAYS_EXPORT = ['words', 'lemmas']

def plural(singular):
    return singular+'s'

class Token(object):
    pass

class Sentence():
    def __init__(self, ctx_beg, ctx_end, kw_pos, kw_len, i=None, attribs=None, invoked_names=None):
        self.ctx_beg = ctx_beg
        self.ctx_end = ctx_end
        self.length = ctx_end - ctx_beg
        self.kw_start = kw_pos - ctx_beg
        self.kw_end = kw_pos - ctx_beg + kw_len
        self.i = i
        self.attribs = attribs
        self.invoked_names = invoked_names
    
    def next_kw(self):
        if self.kw_end >= self.length:
            return False
        else:
            self.kw_start += 1
            self.kw_end += 1
            return True
        
    def export_vars(self):
        variables = {'length': self.length, 'kw_start': self.kw_start, 'kw_end': self.kw_end}
        for attr, attrib in self.attribs.items():
            if plural(attr) in ALWAYS_EXPORT + self.invoked_names:
                text_iter = attrib.textat(self.ctx_beg)
                variables[plural(attr)] = [text_iter.next() for _ in xrange(self.length)]
        if 'tokens' in self.invoked_names:
            tokens = []
            for pos in xrange(self.ctx_beg, self.ctx_end):
                token = Token()
                for attr, attrib in self.attribs.items():
                    setattr(token, attr, attrib.pos2str(pos))
                tokens.append(token)
            variables['tokens'] = tokens
        return variables

    def set_id_set(self, attrib):
        id_iter = attrib.posat(self.ctx_beg)
        self.id_set = set([id_iter.next() for _ in xrange(self.ctx_beg, self.ctx_end)])



class CollocCache:
    def __init__(self, corp):
        self.corpus = corp
        self.default_conc = None
        self.cache = {}

    def set_default_conc(self, conc):
        self.default_conc = conc
        for key in self.cache.keys():
            if key[0] is None:
                del(self.cache[key])

    def get_collocs(self, keyword, colfuncc, attr, minfreq, mincnt, fromw, tow, maxitems):
        if self.default_conc is not None:
            keyword = None
        cache_key = (keyword, colfuncc, attr, minfreq, mincnt, fromw, tow, maxitems)
        if cache_key not in self.cache:
            if keyword is None:
                conc = self.default_conc
            else:
                conc = self._get_conc(attr, keyword)
            collocations = {}
            coll_items = manatee.CollocItems(conc, attr, colfuncc, minfreq, mincnt, fromw, tow, maxitems)
            while (not coll_items.eos()):
                collocations[coll_items.get_item()] = coll_items.get_bgr(colfuncc)
                coll_items.next()
            self.cache[cache_key] = collocations
        return self.cache[cache_key]

    def _get_conc(self, attr, keyword):
        query = u' '.join([u'[%s=="%s"]' % (attr, token.replace(u'"',u'\\"')) for token in keyword])
        result = self.corpus.eval_query(query)
        result.thisown = False
        conc = manatee.Concordance(self.corpus, result)
        conc.sync()
        return conc



class FreqCache():
    def __init__(self, attrib):
        self.attrib = attrib
        self.size = attrib.size()
        self.cache = {}
    def __getitem__(self, value):
        return self.cache.setdefault(value, self.attrib.freq(self.attrib.str2id(value)))



def check_configuration(config):
    if '\t' in config:
        return (False, 'TABs are not allowed by YAML syntax.')
    try:
        config_dict = yaml.safe_load(config)
    except Exception, e:
        return (False, 'Configuration is not valid YAML: ' + str(e))
    if not hasattr(config_dict, 'has_key'):
        return (False, 'Configuration must be a YAML associative array')
    if not config_dict.has_key('formula'):
        return (False, 'Configuration must contain key "formula"')
    try:
        ast, _ = sanitize(unicode(config_dict['formula']))
    except Exception, e:
        return (False, str(e))
    try:
        compile(ast, '<string>', mode='eval')
    except:
        return (False, 'Formula could not be compiled.')
    return (True, 'OK')



class GDEX:
    def __init__(self, corp, conf_path=None, precalculated=True, debug=False, config=None):
        self.debug = debug
        manatee.setEncoding(corp.get_conf('ENCODING'))
        attribs = dict([(attr, corp.get_attr(attr)) for attr in corp.get_conf('ATTRLIST').split(',')])
        self.default_attrib = attribs[corp.get_conf('DEFAULTATTR')]
        self.precalculated = precalculated and GDEXATTR in attribs
        if self.precalculated:
            self.gdex_attrib = attribs[GDEXATTR]
        else:
            self.attribs = attribs
            if not config:
                conf_path = conf_path or corp.get_conf('GDEXDEFAULTCONF')
                if conf_path:
                    with open(conf_path) as f:
                        config = f.read()
                else:
                    config = DEFAULT_CONFIG
            config_dict = yaml.safe_load(config)
            ast, self.invoked_names = sanitize(unicode(config_dict['formula']))
            self.code_object = compile(ast, '<string>', mode='eval')
            self.variables = config_dict.get('variables', {})
            if 'debug' in config_dict:
                self.debug = bool(config_dict['debug']) or debug
            if 'frequency_reference_corpus' in config_dict:
                self.freq_corpus = manatee.Corpus(config_dict['frequency_reference_corpus'])
                freq_attrlist = self.freq_corpus.get_conf('ATTRLIST').split(',')
                if 'word' in freq_attrlist:
                    self.word_freq_cache = FreqCache(self.freq_corpus.get_attr('word'))
                if 'lemma' in freq_attrlist:
                    self.lemma_freq_cache = FreqCache(self.freq_corpus.get_attr('lemma'))
            else:
                self.freq_corpus = corp
                if 'word' in attribs:
                    self.word_freq_cache = FreqCache(attribs['word'])
                if 'lemma' in attribs:
                    self.lemma_freq_cache = FreqCache(attribs['lemma'])
            self.coll_cache = CollocCache(corp)
    
    def get_score(self, sentence, devel_mode=False):
        if self.precalculated:
            return float(self.gdex_attrib.pos2str(sentence.ctx_beg + sentence.kw_start)) / DEFAULT_COEF
        # prepare variables
        variables = dict(self.variables.items() + sentence.export_vars().items())
        # prepare classifiers
        from classifiers import all, match, count_matches, blacklist, whitelist, mw_blacklist, greylist, optimal_interval, legacy_optimal_interval, minmax, space_separated
        from random import random
        keyword_position = lambda: classifiers.keyword_position(variables)
        def is_whole_sentence(pattern='^[.!?]$'):
            return classifiers.is_whole_sentence(variables, pattern)
        def keyword_repetition(tokens=None):
            return classifiers.keyword_repetition(variables, tokens)
        keyword_not_capitalized = lambda: classifiers.keyword_not_capitalized(variables)
        def word_frequency(word, normalize=None):
            return classifiers.token_frequency(self.word_freq_cache, word, normalize)
        def lemma_frequency(lemma, normalize=None):
            return classifiers.token_frequency(self.lemma_freq_cache, lemma, normalize)
        word_occurrences = lambda word: word_frequency(word) # legacy
        def lemma_collocation_scores(fromw=-5, tow=5, minfreq=5, mincnt=3, maxitems=1000000, colfunc='LOGDICE'):
            return classifiers.collocation_scores(self.coll_cache, variables, 'lemma', fromw, tow, minfreq, mincnt, maxitems, colfunc)
        # developer mode
        if devel_mode:
            subscores = {}
            def _(label, subscore):
                subscores[label] = float(subscore)
                return subscore
        else:
            _ = lambda label, subscore: subscore
        # evaluate
        try:
            score = eval(self.code_object)
            if devel_mode:
                return score, subscores
            else:
                return min(max(float(score), 0), 1)
        except Exception, e:
            if self.debug:
                raise
            else:
                return EVAL_FAILED_SCORE

    def set_concordance(self, conc):
        conc.sync()
        self.conc = conc
        if not self.precalculated:
            self.coll_cache.set_default_conc(conc)

    # legacy
    def entryConc(self, conc, collattrname=None, collattrvalue=None):
        self.set_concordance(conc)

    def get_sentences(self, sample_size):
        kw = manatee.KWICLines(self.conc.corp(), self.conc.RS(), '-1:s', '1:s', 'word', 'word', 's', '#')
        sample_size = min(sample_size, self.conc.size())
        sample = sorted(random.Random(5).sample(xrange(self.conc.size()), sample_size))
        last_index = 0
        for i in sample:
            kw.skip(i - last_index)
            last_index = i + 1
            ctxbeg = kw.get_ctxbeg()
            ctxend = kw.get_ctxend()
            if ctxend - ctxbeg > 1000:
                continue
            if ctxend < ctxbeg:
                continue
            if self.precalculated:
                yield Sentence(ctxbeg, ctxend, kw.get_pos(), kw.get_kwiclen(), i)
            else:
                yield Sentence(ctxbeg, ctxend, kw.get_pos(), kw.get_kwiclen(), i, self.attribs, self.invoked_names)

    def best_k(self, k=float('inf'), maxconcsize=1000, minscore=0, distance=0.3):
        return [(val, s.i) for val, s in self.best_k_sentences(k, maxconcsize, minscore, distance)]

    def best_k_with_toknum(self, k=float('inf'), maxconcsize=1000, minscore=0, distance=0.3):
        return [(val, s.i, s.ctx_beg + s.kw_start) for val, s in self.best_k_sentences(k, maxconcsize, minscore, distance)]

    def best_k_sentences(self, k, sample_size, min_score, min_distance, devel_mode=False):
        lines = []
        for s in self.get_sentences(sample_size):
            if devel_mode:
                score, subscores = self.get_score(s, devel_mode=True)
                lines.append((score, s, subscores))
            else:
                score = self.get_score(s)
                if score >= min_score:
                    lines.append((score, s))
        lines.sort(reverse=True)
        k = min(len(lines), k)
        if min_distance > 0:
            lines = self.deduplicate(lines, min_distance, k)
        return lines[:k]

    def deduplicate(self, lines, min_distance, k):
        winners = []
        losers = []
        i = 0
        while len(winners) < k and len(lines) > i:
            contestant = lines[i]
            i += 1
            contestant[1].set_id_set(self.default_attrib)
            is_unique = True
            for winner in winners:
                jaccard_distance = 1 - len(contestant[1].id_set & winner[1].id_set) / len(contestant[1].id_set | winner[1].id_set)
                if jaccard_distance <= min_distance:
                    is_unique = False
                    break
            if is_unique:
                winners.append(contestant)
            else:
                losers.append(contestant)
        return winners + losers + lines[i:]

