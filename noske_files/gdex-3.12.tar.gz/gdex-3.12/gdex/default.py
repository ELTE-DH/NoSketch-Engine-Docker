DEFAULT_CONFIG = """formula: >
    (50 * all(is_whole_sentence(), blacklist(words, illegal_chars), min([word_occurrences(w) for w in words]) > 2)
    + 50 * optimal_interval(length, 8, 20)
    * sum([1/length for w in words if word_frequency(w, 1000000) > 1])
    * greylist(words, rare_chars, 0.05)
    ) / 100

variables:
    rare_chars: ([A-Z'"`.,!?)(;:#$%&-])
    illegal_chars: ([<>|\]\[}{/\\\\^@+=_~*])
"""

