#!/usr/bin/python
from setuptools import setup

setup(
      name='gdex',
      version='3.12',
      description='Good Dictionary Examples',
      long_description='GDEX (Good Dictionary Examples) is a Bonito module for sorting concordances according to their suitability as dictionary examples.',
      author='Lexical Computing',
      author_email='support@sketchengine.eu',
      url='https://www.sketchengine.eu/guide/gdex/',
      license='GPLv3',
      platforms='any',
      install_requires=['PyYAML'],
      python_requires='<3',
      packages=['gdex'],
      scripts=["add_gdex"],
)
