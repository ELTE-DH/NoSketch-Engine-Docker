import manatee
import random
import yaml
from .classifiers import Context
from .sanitization import sanitize
from .default import DEFAULT_CONFIG

GDEXATTR = 'gdex'
DEFAULT_COEF = 999
ALWAYS_EXPORT = ['words', 'lemmas']

def plural(singular):
    return singular+'s'

class Token(object):
    pass

class Sentence():
    def __init__(self, ctx_beg, ctx_end, kw_pos, kw_len, i=None, attribs=None, invoked_names=None):
        self.ctx_beg = ctx_beg
        self.ctx_end = ctx_end
        self.length = ctx_end - ctx_beg
        self.kw_start = kw_pos - ctx_beg
        self.kw_end = kw_pos - ctx_beg + kw_len
        self.i = i
        self.attribs = attribs
        self.invoked_names = invoked_names
    
    def next_kw(self):
        if self.kw_end >= self.length:
            return False
        else:
            self.kw_start += 1
            self.kw_end += 1
            return True
        
    def export_vars(self):
        variables = {'length': self.length, 'kw_start': self.kw_start, 'kw_end': self.kw_end}
        for attr, attrib in self.attribs.items():
            if plural(attr) in ALWAYS_EXPORT + self.invoked_names:
                text_iter = attrib.textat(self.ctx_beg)
                variables[plural(attr)] = [text_iter.next() for _ in range(self.length)]
        if 'tokens' in self.invoked_names:
            tokens = []
            for pos in range(self.ctx_beg, self.ctx_end):
                token = Token()
                for attr, attrib in self.attribs.items():
                    setattr(token, attr, attrib.pos2str(pos))
                tokens.append(token)
            variables['tokens'] = tokens
        return variables

    def set_id_set(self, attrib):
        id_iter = attrib.posat(self.ctx_beg)
        self.id_set = set([id_iter.next() for _ in range(self.ctx_beg, self.ctx_end)])



class CollocCache:
    def __init__(self, corp):
        self.corpus = corp
        self.default_conc = None
        self.cache = {}

    def set_default_conc(self, conc):
        self.default_conc = conc
        self.cache = {k:v for k, v in self.cache.items() if k is not None}

    def get_collocs(self, keyword, colfuncc, attr, minfreq, mincnt, fromw, tow, maxitems):
        if self.default_conc is not None:
            keyword = None
        cache_key = (keyword, colfuncc, attr, minfreq, mincnt, fromw, tow, maxitems)
        if cache_key not in self.cache:
            if keyword is None:
                conc = self.default_conc
            else:
                conc = self._get_conc(attr, keyword)
            collocations = {}
            coll_items = manatee.CollocItems(conc, attr, colfuncc, minfreq, mincnt, fromw, tow, maxitems)
            while (not coll_items.eos()):
                collocations[coll_items.get_item()] = coll_items.get_bgr(colfuncc)
                coll_items.next()
            self.cache[cache_key] = collocations
        return self.cache[cache_key]

    def _get_conc(self, attr, keyword):
        query = ' '.join(['[%s=="%s"]' % (attr, token.replace('"','\\"')) for token in keyword])
        result = self.corpus.eval_query(query)
        result.thisown = False
        conc = manatee.Concordance(self.corpus, result)
        conc.sync()
        return conc



class FreqCache():
    def __init__(self, corp, attr):
        self.corp = corp
        self.attr = attr
        self.size = corp.size()
        self.cache = {}
    def __getitem__(self, key):
        if key in self.cache:
            return self.cache[key]
        else:
            attrib = self.corp.get_attr(self.attr)
            value = attrib.freq(attrib.str2id(key))
            self.cache[key] = value
            return value



def check_configuration(config):
    if '\t' in config:
        return (False, 'TABs are not allowed by YAML syntax.')
    try:
        config_dict = yaml.safe_load(config)
    except Exception as e:
        return (False, 'Configuration is not valid YAML: ' + str(e))
    if 'formula' not in config_dict:
        return (False, 'Configuration must contain key "formula"')
    try:
        ast, _ = sanitize(str(config_dict['formula']))
    except Exception as e:
        return (False, str(e))
    try:
        compile(ast, '<string>', mode='eval')
    except:
        return (False, 'Formula could not be compiled.')
    return (True, 'OK')



class GDEX:
    def __init__(self, corp, conf_path=None, precalculated=True, config=None):
        manatee.setEncoding(corp.get_conf('ENCODING'))
        attribs = dict([(attr, corp.get_attr(attr)) for attr in corp.get_conf('ATTRLIST').split(',')])
        self.default_attrib = attribs[corp.get_conf('DEFAULTATTR')]
        self.precalculated = precalculated and GDEXATTR in attribs
        if self.precalculated:
            self.gdex_attrib = attribs[GDEXATTR]
        else:
            self.attribs = attribs
            if not config:
                conf_path = conf_path or corp.get_conf('GDEXDEFAULTCONF')
                if conf_path:
                    with open(conf_path) as f:
                        config = f.read()
                else:
                    config = DEFAULT_CONFIG
            config_dict = yaml.safe_load(config)
            ast, self.invoked_names = sanitize(str(config_dict['formula']))
            self.code_object = compile(ast, '<string>', mode='eval')
            if 'frequency_reference_corpus' in config_dict:
                freq_corpus = manatee.Corpus(config_dict['frequency_reference_corpus'])
                freq_attrlist = freq_corpus.get_conf('ATTRLIST').split(',')
            else:
                freq_corpus = corp
                freq_attrlist = attribs
            self.context = Context()
            self.context.constants = config_dict.get('variables', {}) # bad naming
            if 'word' in freq_attrlist:
                self.context.word_freq_cache = FreqCache(freq_corpus, 'word')
            if 'lemma' in freq_attrlist:
                self.context.lemma_freq_cache = FreqCache(freq_corpus, 'lemma')
            self.context.coll_cache = CollocCache(corp)
    
    def get_score(self, sentence, devel_mode=False):
        if self.precalculated:
            return float(self.gdex_attrib.pos2str(sentence.ctx_beg + sentence.kw_start)) / DEFAULT_COEF
        self.context.variables = sentence.export_vars()
        self.context.subscores = {}
        score = eval(self.code_object, self.context.get_dict())
        score = float(score)
        if devel_mode:
            return score, self.context.subscores
        else:
            return min(max(score, 0), 1)

    def set_concordance(self, conc):
        conc.sync()
        self.conc = conc
        if not self.precalculated:
            self.context.coll_cache.set_default_conc(conc)

    # legacy
    def entryConc(self, conc, collattrname=None, collattrvalue=None):
        self.set_concordance(conc)

    def get_sentences(self, sample_size):
        kw = manatee.KWICLines(self.conc.corp(), self.conc.RS(), '-1:s', '1:s', 'word', 'word', 's', '#')
        sample_size = min(sample_size, self.conc.size())
        sample = sorted(random.Random(5).sample(range(self.conc.size()), sample_size))
        last_index = 0
        for i in sample:
            kw.skip(i - last_index)
            last_index = i + 1
            ctxbeg = kw.get_ctxbeg()
            ctxend = kw.get_ctxend()
            if ctxend - ctxbeg > 1000:
                continue
            if ctxend < ctxbeg:
                continue
            if self.precalculated:
                yield Sentence(ctxbeg, ctxend, kw.get_pos(), kw.get_kwiclen(), i)
            else:
                yield Sentence(ctxbeg, ctxend, kw.get_pos(), kw.get_kwiclen(), i, self.attribs, self.invoked_names)

    def best_k(self, k=float('inf'), maxconcsize=1000, minscore=0, distance=0.3):
        return [(val, s.i) for val, s in self.best_k_sentences(k, maxconcsize, minscore, distance)]

    def best_k_with_toknum(self, k=float('inf'), maxconcsize=1000, minscore=0, distance=0.3):
        return [(val, s.i, s.ctx_beg + s.kw_start) for val, s in self.best_k_sentences(k, maxconcsize, minscore, distance)]

    def best_k_sentences(self, k, sample_size, min_score, min_distance, devel_mode=False):
        lines = []
        for s in self.get_sentences(sample_size):
            if devel_mode:
                score, subscores = self.get_score(s, devel_mode=True)
                lines.append((score, s, subscores))
            else:
                score = self.get_score(s)
                if score >= min_score:
                    lines.append((score, s))
        lines.sort(key=lambda s: s[0], reverse=True)
        k = min(len(lines), k)
        if min_distance > 0:
            lines = self.deduplicate(lines, min_distance, k)
        return lines[:k]

    def deduplicate(self, lines, min_distance, k):
        winners = []
        losers = []
        i = 0
        while len(winners) < k and len(lines) > i:
            contestant = lines[i]
            i += 1
            contestant[1].set_id_set(self.default_attrib)
            is_unique = True
            for winner in winners:
                jaccard_distance = 1 - len(contestant[1].id_set & winner[1].id_set) / len(contestant[1].id_set | winner[1].id_set)
                if jaccard_distance <= min_distance:
                    is_unique = False
                    break
            if is_unique:
                winners.append(contestant)
            else:
                losers.append(contestant)
        return winners + losers + lines[i:]

