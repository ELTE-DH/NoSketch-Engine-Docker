import random
import re

def all(*args):
    for arg in args:
        if not bool(arg):
            return 0
    return 1

def match(token, pattern):
    return 1 if re.search(pattern, token) else 0

def count_matches(tokens, pattern):
    compiled_pattern = re.compile(pattern)
    return sum([1 for token in tokens if compiled_pattern.search(token)])

def greylist(tokens, pattern, penalty):
    return max(0, 1 - penalty*count_matches(tokens, pattern))

def blacklist(tokens, pattern):
    compiled_pattern = re.compile(pattern)
    for token in tokens:
        if compiled_pattern.search(token):
            return 0
    return 1

def whitelist(tokens, pattern):
    compiled_pattern = re.compile(pattern)
    for token in tokens:
        if not compiled_pattern.search(token):
            return 0
    return 1

def mw_blacklist(tokens, pattern):
    return not bool(re.search(pattern, ' '.join(tokens)))

def optimal_interval(val, low, high):
    if val < low:
        return max(0, 2*(val - low/2)/low)
    elif val > high:
        return max(0, 1 - (val - high)/high)
    else:
        return 1
    
def legacy_optimal_interval(val, low, high):
    if val < low:
        if low > 0:
            return max(0.0, val / low)
        elif low < 0:
            return low / val
        else:
            return 0.0
    elif val > high:
        if high > 0:
            return high / val
        elif high < 0:
            return max(0.0, val / high)
        else:
            return 0.0
    else:
        return 1.0

def token_frequency(freq_cache, token, normalize=None):
    freq = freq_cache[token]
    if normalize is not None:
        coef = normalize / freq_cache.size
    else:
        coef = 1
    return freq * coef

def minmax(low, high, val):
    if val < low:
        return low
    elif val > high:
        return high
    else:
        return val

def space_separated(tokens):
    return ' '.join(tokens)


colfuncs_dict = {'TSCORE':'t', 'MISCORE':'m', 'MI3SCORE':'3',
                 'LOGLIKEH':'l', 'MINSENS':'s', 'PROD_MI.LOG_F':'p',
                 'RELFREQ':'r', 'ABSFREQ':'f', 'PRODMIREL':'C',
                 'DICE':'D', 'LOGDICE':'d', 'LOG10DICE':'1'}
def collocation_scores(coll_cache, vars, attr, fromw=-5, tow=5, minfreq=5, mincnt=3, maxitems=1000000, colfunc='LOGDICE'):
    tokens = vars[attr + 's']
    keyword = tuple(tokens[vars['kw_start']:vars['kw_end']])
    colfuncc = colfuncs_dict[colfunc]
    all_collocs = coll_cache.get_collocs(keyword, colfuncc, attr, minfreq, mincnt, fromw, tow, maxitems)
    return [all_collocs.get(x, 0) for x in tokens]

class Context:
    def save_subscore(self, label, subscore):
        self.subscores[label] = float(subscore)
        return subscore

    def is_whole_sentence(self, pattern='^[.!?]$'):
        words = self.variables['words']
        if (words and words[0] and words[0][0].isupper() and re.search(pattern, words[-1])):
            return 1
        else:
            return 0

    def keyword_position(self):
        try:
            return self.variables['kw_start'] / (self.variables['length'] - self.variables['kw_end'] + self.variables['kw_start'])
        except:
            return 1

    def keyword_repetition(self, tokens=None):
        if tokens is None:
            tokens = self.variables['words']
        start = self.variables['kw_start']
        end = self.variables['kw_end']
        c = tokens.count(tokens[start])
        if (end - start == 1) or (c == 1):
            return c
        else:
            c = 0
            pos = 0
            send = self.variables['length'] - end + start + 1
            try:
                first = tokens[start]
                rest = tokens[start + 1:end]
                while(True):
                    pos = tokens.index(first, pos) + 1
                    if pos > send:
                        return c
                    for i, w in enumerate(rest):
                        if not tokens[pos + i] == w:
                            c -= 1
                            break
                    c += 1
            except ValueError:
                return c

    def keyword_not_capitalized(self):
        kw_start = self.variables['kw_start']
        if kw_start == 0:
            return 1 # can't say; first word in sentence
        word = self.variables['words'][kw_start]
        if word and word[0].isupper():
            return 0
        else:
            return 1

    def word_frequency(self, word, normalize=None):
        return token_frequency(self.word_freq_cache, word, normalize)
    def lemma_frequency(self, lemma, normalize=None):
        return token_frequency(self.lemma_freq_cache, lemma, normalize)
    def word_occurrences(self, word): # legacy name
        return token_frequency(self.word_freq_cache, word)

    def lemma_collocation_scores(self, fromw=-5, tow=5, minfreq=5, mincnt=3, maxitems=1000000, colfunc='LOGDICE'):
        return collocation_scores(self.coll_cache, self.variables, 'lemma', fromw, tow, minfreq, mincnt, maxitems, colfunc)

    def get_dict(self):
        return {
            '_': self.save_subscore,
            'variables': {**self.constants, **self.variables},
            'is_whole_sentence': self.is_whole_sentence,
            'keyword_position': self.keyword_position,
            'keyword_repetition': self.keyword_repetition,
            'keyword_not_capitalized': self.keyword_not_capitalized,
            'word_frequency': self.word_frequency, 'lemma_frequency': self.lemma_frequency, 'word_occurrences': self.word_occurrences,
            'lemma_collocation_scores': self.lemma_collocation_scores,
            'all': all, 'match': match, 'count_matches': count_matches, 'blacklist': blacklist, 'whitelist': whitelist, 'mw_blacklist': mw_blacklist, 'greylist': greylist, 'optimal_interval': optimal_interval, 'legacy_optimal_interval': legacy_optimal_interval, 'minmax': minmax, 'space_separated': space_separated, 'random': random.random,
        }
