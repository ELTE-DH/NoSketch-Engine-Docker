import ast

PERMITTED_FUNCTIONS = ['abs', 'min', 'max', 'sum', 'len', 'random', 'int',
                       'all', 'is_whole_sentence', 'match', 'count_matches', 'blacklist', 'whitelist', 'mw_blacklist', 'greylist', 'optimal_interval', 'legacy_optimal_interval', 'word_frequency', 'lemma_frequency', 'word_occurrences', 'keyword_position', 'minmax', 'keyword_repetition', 'keyword_not_capitalized', 'space_separated', 'lemma_collocation_scores',
                       '_'
                      ]
PERMITTED_NODES = [ast.Expression, ast.Constant, ast.Num, ast.Str, ast.Call, ast.keyword,
                   ast.BinOp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod,
                   ast.Compare, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.Eq, ast.NotEq,
                   ast.UnaryOp, ast.Not, ast.USub,
                   ast.BoolOp, ast.And, ast.Or,
                   ast.Attribute, ast.Subscript, ast.Index, ast.comprehension, ast.ListComp, ast.Slice,
                   ast.Load,
                  ]


class SanitizationException(Exception):
    pass


class Sanitizer(ast.NodeTransformer):
    def __init__(self):
        self.invoked_names = []
        super(Sanitizer, self).__init__()

    def visit_Name(self, node):
        self.invoked_names.append(node.id)
        # lock into variables[]
        return ast.Subscript(
            value=ast.Name(id='variables', ctx=ast.Load()),
            slice=ast.Index(value=ast.Str(s=node.id)),
            ctx=node.ctx
        )

    def visit_Call(self, node):
        # check if permitted
        if not isinstance(node.func, ast.Attribute): # methods always permitted
            if node.func.id not in PERMITTED_FUNCTIONS:
                raise SanitizationException('Calling %s is not permitted' % node.func.id)
        # visit children EXCEPT FUNCTION NAME
        for field, old_value in ast.iter_fields(node):
            old_value = getattr(node, field, None)
            if field == 'func':
                if isinstance(old_value, ast.Attribute):
                    old_value.value = self.visit(old_value.value)
                    node.func = old_value
            elif isinstance(old_value, ast.AST):
                new_node = self.visit(old_value)
                if new_node is None:
                    delattr(node, field)
                else:
                    setattr(node, field, new_node)
            elif isinstance(old_value, list):
                new_values = []
                for value in old_value:
                    if isinstance(value, ast.AST):
                        value = self.visit(value)
                        if value is None:
                            continue
                        elif not isinstance(value, ast.AST):
                            new_values.extend(value)
                            continue
                    new_values.append(value)
                old_value[:] = new_values
        return node
    
    def generic_visit(self, node):
        # check if permitted
        if type(node) not in PERMITTED_NODES:
            raise SanitizationException('Using %s is not permitted' % type(node).__name__)
        return ast.NodeTransformer.generic_visit(self, node)
    
    
def sanitize(formula):
    sanitizer = Sanitizer()
    tree = ast.parse(formula, mode='eval') # throws SyntaxError
    tree = ast.fix_missing_locations(sanitizer.visit(tree)) # throws SanitizationException
    return tree, sanitizer.invoked_names

