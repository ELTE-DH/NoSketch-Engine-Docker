#!/usr/bin/python3

from setuptools import setup

setup(
      name='gdex',
      version='<version>',
      description='Good Dictionary Examples',
      long_description='GDEX (Good Dictionary Examples) is a Bonito module for sorting concordances according to their suitability as dictionary examples.',
      author='Lexical Computing',
      author_email='support@sketchengine.eu',
      url='https://www.sketchengine.eu',
      project_urls={"Documentation": "https://www.sketchengine.eu/guide/gdex/",},
      license='GPLv3',
      platforms='any',
      install_requires=['PyYAML'],
      packages=['gdex'],
      scripts=["add_gdex"],
)
